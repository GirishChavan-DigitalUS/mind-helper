"""Fetch total record counts for each IDS Bridge GraphQL entity.

Reads the entity list, sends a minimal paginated query per entity requesting
only `paginatorInfo.total`, and prints a summary table.

Configuration is read from environment variables (preferred) or the constants
below:
    IDS_BRIDGE_URL    - GraphQL endpoint
    IDS_BRIDGE_TOKEN  - Bearer access token
"""

from __future__ import annotations

import os
import sys
from typing import Optional

import requests

# --- Configuration ---------------------------------------------------------
# Prefer environment variables; fall back to the values below.
DEFAULT_URL = "https://sg.idsdatanet.com/ids-bridge/v3/graphql"

API_URL = os.environ.get("IDS_BRIDGE_URL", DEFAULT_URL)
API_TOKEN = os.environ.get("IDS_BRIDGE_TOKEN", "")

REQUEST_TIMEOUT = 60  # seconds

# GraphQL root query field name for each entity in the collection.
# Entities marked in the Postman collection as UNAVAILABLE / UNAUTHORIZED
# are included but may return errors.
ENTITIES = [
    "campaigns",
    "wells",
    "wellbores",
    "activities",
    "unwantedEvents",
    "operations",
    "bharuns",
    "bharunDailySummaries",
    "bhaComponents",
    "reportDailies",
    "operationPlanPhases",
    "drillingParameters",
    "casingSections",
    "operationPlanMasters",
    "rigStocks",
    "solidControlEquipments",
    "mudVolumes",
    "mudVolumeDetails",
    "drillreports",
]


def build_query(entity: str) -> str:
    """Return a minimal query that only asks for the total record count."""
    return (
        f"query {{ {entity}(page: 1, first: 1) "
        "{ paginatorInfo { total } } }"
    )


def fetch_total(session: requests.Session, entity: str) -> tuple[Optional[int], Optional[str]]:
    """Return (total, error_message) for a single entity."""
    try:
        response = session.post(
            API_URL,
            json={"query": build_query(entity)},
            timeout=REQUEST_TIMEOUT,
        )
    except requests.RequestException as exc:
        return None, f"request failed: {exc}"

    if response.status_code != 200:
        return None, f"HTTP {response.status_code}: {response.text[:200]}"

    try:
        payload = response.json()
    except ValueError:
        return None, f"invalid JSON: {response.text[:200]}"

    if payload.get("errors"):
        messages = "; ".join(
            err.get("message", "unknown error") for err in payload["errors"]
        )
        return None, messages

    data = payload.get("data") or {}
    entity_data = data.get(entity) or {}
    paginator = entity_data.get("paginatorInfo") or {}
    total = paginator.get("total")

    if total is None:
        return None, "no paginatorInfo.total in response"

    return int(total), None


def main() -> int:
    if not API_TOKEN:
        print(
            "ERROR: No access token provided. Set the IDS_BRIDGE_TOKEN "
            "environment variable.",
            file=sys.stderr,
        )
        return 1

    session = requests.Session()
    session.headers.update(
        {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {API_TOKEN}",
        }
    )

    print(f"Querying {API_URL}\n")

    name_width = max(len(name) for name in ENTITIES)
    results: list[tuple[str, Optional[int]]] = []

    for entity in ENTITIES:
        total, error = fetch_total(session, entity)
        results.append((entity, total))
        if error:
            print(f"{entity:<{name_width}}  ERROR: {error}")
        else:
            print(f"{entity:<{name_width}}  {total:>12,}")

    grand_total = sum(t for _, t in results if t is not None)
    print("\n" + "-" * (name_width + 16))
    print(f"{'TOTAL':<{name_width}}  {grand_total:>12,}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
