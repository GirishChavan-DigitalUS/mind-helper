"""IDS Bridge GraphQL bulk extractor.

What it does
------------
For every entity listed in ``config.json`` this script:

1. Loads a parameterized GraphQL query template (``queries/<entity>.graphql``)
   that accepts ``$page`` and ``$first`` variables.
2. Paginates from page 1 using the configured page size, following
   ``paginatorInfo.hasMorePages`` / ``total`` until every record is retrieved.
3. Writes **each page separately** to ``output/pages/<entity>/page_00001.json``
   so a failure mid-run never loses already-fetched data.
4. After all pages succeed, **merges** the per-page files into one complete
   file per entity (``output/<entity>.json`` or ``.ndjson``) ready for
   Snowflake ingestion.
5. Records a per-entity status in ``output/_run_summary.json``.

Design goals
------------
* **Non-interrupting**: a failure in one page or one entity is logged and the
  script keeps going. Nothing raises out of the per-entity loop.
* **Resilient network I/O**: transient HTTP errors are retried with backoff.
* **Auditable**: page files, a run summary, and clear console logging.

Configuration
-------------
All behaviour is driven by ``config.json`` (see ``generate_queries.py``). The
bearer token is read from the environment variable named by
``config.api.token_env`` (default ``IDS_BRIDGE_TOKEN``) so secrets never live in
source control.

Usage
-----
    set IDS_BRIDGE_TOKEN=<token>            # PowerShell: $env:IDS_BRIDGE_TOKEN
    python ids_extract.py                   # run everything in config
    python ids_extract.py --page-size 250   # override page size
    python ids_extract.py --entities wells campaigns
    python ids_extract.py --format ndjson   # Snowflake-friendly output
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import time
from dataclasses import dataclass, field
from typing import Any, Optional

import requests

# --------------------------------------------------------------------------- #
# Logging
# --------------------------------------------------------------------------- #
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-7s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("ids_extract")


# --------------------------------------------------------------------------- #
# Result bookkeeping
# --------------------------------------------------------------------------- #
@dataclass
class EntityResult:
    """Outcome of extracting a single entity, captured for the run summary."""

    name: str
    status: str = "pending"          # ok | partial | failed | skipped
    expected_total: Optional[int] = None
    records_fetched: int = 0
    pages_fetched: int = 0
    output_file: Optional[str] = None
    errors: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "status": self.status,
            "expected_total": self.expected_total,
            "records_fetched": self.records_fetched,
            "pages_fetched": self.pages_fetched,
            "output_file": self.output_file,
            "errors": self.errors,
        }


# --------------------------------------------------------------------------- #
# Configuration loading
# --------------------------------------------------------------------------- #
def load_config(path: str) -> dict[str, Any]:
    """Load and return the JSON config, exiting on a fatal problem."""
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        log.error("Config file not found: %s", path)
        sys.exit(2)
    except json.JSONDecodeError as exc:
        log.error("Config file is not valid JSON: %s", exc)
        sys.exit(2)


def load_query(queries_dir: str, query_file: str) -> str:
    """Read a GraphQL query template from disk."""
    query_path = os.path.join(queries_dir, query_file)
    with open(query_path, "r", encoding="utf-8") as handle:
        return handle.read()


# --------------------------------------------------------------------------- #
# HTTP / GraphQL layer
# --------------------------------------------------------------------------- #
def post_graphql(
    session: requests.Session,
    url: str,
    query: str,
    variables: dict[str, Any],
    timeout: int,
    max_retries: int,
    backoff: float,
) -> dict[str, Any]:
    """Execute one GraphQL request with retry on transient failures.

    Returns the parsed ``data`` object. Raises ``RuntimeError`` when the request
    ultimately fails or the server returns GraphQL ``errors`` (the caller is
    responsible for turning that into a logged, non-fatal outcome).
    """
    payload = {"query": query, "variables": variables}
    last_error = "unknown error"

    for attempt in range(1, max_retries + 1):
        try:
            response = session.post(url, json=payload, timeout=timeout)
        except requests.RequestException as exc:
            # Network-level problem (DNS, connection reset, timeout, ...).
            last_error = f"network error: {exc}"
        else:
            if response.status_code == 200:
                try:
                    body = response.json()
                except ValueError:
                    last_error = f"invalid JSON response: {response.text[:200]}"
                else:
                    if body.get("errors"):
                        # GraphQL-level errors are not transient; do not retry.
                        messages = "; ".join(
                            err.get("message", "unknown GraphQL error")
                            for err in body["errors"]
                        )
                        raise RuntimeError(f"GraphQL error: {messages}")
                    return body.get("data") or {}
            elif response.status_code in (429, 500, 502, 503, 504):
                # Rate limiting / transient server errors are worth retrying.
                last_error = f"HTTP {response.status_code}: {response.text[:200]}"
            else:
                # Other 4xx errors are permanent for this request.
                raise RuntimeError(
                    f"HTTP {response.status_code}: {response.text[:200]}"
                )

        if attempt < max_retries:
            sleep_for = backoff * attempt
            log.warning(
                "Request failed (attempt %d/%d): %s -- retrying in %.1fs",
                attempt,
                max_retries,
                last_error,
                sleep_for,
            )
            time.sleep(sleep_for)

    raise RuntimeError(f"exhausted retries: {last_error}")


# --------------------------------------------------------------------------- #
# Per-entity extraction
# --------------------------------------------------------------------------- #
def extract_entity(
    session: requests.Session,
    entity: dict[str, Any],
    api_cfg: dict[str, Any],
    queries_dir: str,
    page_size: int,
    output_dir: str,
    pages_subdir: str,
    output_format: str,
    keep_page_files: bool,
    timestamp: str,
) -> EntityResult:
    """Extract every record for one entity, page by page, then merge.

    All errors are caught and recorded on the returned ``EntityResult`` so a
    single failure never stops the overall run.
    """
    name = entity.get("name", "<unknown>")
    root_field = entity.get("root_field", name)
    result = EntityResult(name=name)

    # Load the query template up front; a missing file just skips this entity.
    try:
        query = load_query(queries_dir, entity["query_file"])
    except (KeyError, FileNotFoundError, OSError) as exc:
        result.status = "failed"
        result.errors.append(f"could not load query file: {exc}")
        log.error("[%s] %s", name, result.errors[-1])
        return result

    # Directory that holds one JSON file per fetched page for this entity.
    entity_pages_dir = os.path.join(output_dir, pages_subdir, name)
    os.makedirs(entity_pages_dir, exist_ok=True)

    page = 1
    page_files: list[str] = []

    while True:
        variables = {"page": page, "first": page_size}
        try:
            data = post_graphql(
                session,
                api_cfg["url"],
                query,
                variables,
                timeout=api_cfg.get("timeout_seconds", 120),
                max_retries=api_cfg.get("max_retries", 3),
                backoff=api_cfg.get("retry_backoff_seconds", 2),
            )
        except RuntimeError as exc:
            # Record the failure and stop paginating this entity, but keep any
            # pages already written. Mark partial vs failed accordingly.
            result.errors.append(f"page {page}: {exc}")
            result.status = "partial" if page_files else "failed"
            log.error("[%s] page %d failed: %s", name, page, exc)
            break

        # Defensive navigation of the response shape.
        node = data.get(root_field) or {}
        records = node.get("data") or []
        paginator = node.get("paginatorInfo") or {}
        total = paginator.get("total")

        if result.expected_total is None and total is not None:
            result.expected_total = int(total)

        # Persist THIS page on its own so partial progress is never lost.
        page_path = os.path.join(entity_pages_dir, f"page_{page:05d}.json")
        try:
            with open(page_path, "w", encoding="utf-8") as handle:
                json.dump(records, handle, ensure_ascii=False)
        except OSError as exc:
            result.errors.append(f"page {page}: failed to write file: {exc}")
            result.status = "partial" if page_files else "failed"
            log.error("[%s] could not write page %d: %s", name, page, exc)
            break

        page_files.append(page_path)
        result.records_fetched += len(records)
        result.pages_fetched += 1

        log.info(
            "[%s] page %d: %d records (running %d / %s)",
            name,
            page,
            len(records),
            result.records_fetched,
            result.expected_total if result.expected_total is not None else "?",
        )

        # Decide whether to continue. Prefer the explicit hasMorePages flag,
        # and fall back to comparing against the reported total. An empty page
        # is always a safe stopping point.
        has_more = paginator.get("hasMorePages")
        if not records:
            break
        if has_more is False:
            break
        if has_more is None and result.expected_total is not None:
            if result.records_fetched >= result.expected_total:
                break

        page += 1

    # If we fetched everything expected, mark ok; keep partial/failed otherwise.
    if not result.errors:
        if (
            result.expected_total is None
            or result.records_fetched >= result.expected_total
        ):
            result.status = "ok"
        else:
            result.status = "partial"

    # Merge the per-page files into one complete output file for the entity.
    # The output name carries the run timestamp so repeat runs never overwrite
    # previously generated data files.
    merged_ok = False
    if page_files:
        try:
            result.output_file = merge_pages(
                page_files, output_dir, name, output_format, timestamp
            )
            merged_ok = True
        except OSError as exc:
            result.errors.append(f"merge failed: {exc}")
            result.status = "partial"
            log.error("[%s] merge failed: %s", name, exc)

        # Clean up the intermediate per-page files once they have been merged,
        # so no duplicate data is left sitting on disk. We only delete when the
        # merge succeeded, to avoid destroying the sole copy of the data.
        if merged_ok and not keep_page_files:
            for path in page_files:
                try:
                    os.remove(path)
                except OSError:
                    pass
            # Remove the now-empty per-entity page directory too.
            try:
                os.rmdir(entity_pages_dir)
            except OSError:
                pass

    log.info(
        "[%s] done: status=%s records=%d pages=%d",
        name,
        result.status,
        result.records_fetched,
        result.pages_fetched,
    )
    return result


def merge_pages(
    page_files: list[str],
    output_dir: str,
    entity_name: str,
    output_format: str,
    timestamp: str,
) -> str:
    """Combine per-page JSON files into a single timestamped output file.

    * ``array``  -> a single pretty JSON array
      (``output/<entity>_<timestamp>.json``).
    * ``ndjson`` -> one JSON object per line
      (``output/<entity>_<timestamp>.ndjson``), the format Snowflake ingests
      most efficiently via COPY INTO.

    The timestamp suffix guarantees a new run never overwrites earlier output.
    Returns the path of the written file.
    """
    if output_format == "ndjson":
        out_path = os.path.join(output_dir, f"{entity_name}_{timestamp}.ndjson")
        with open(out_path, "w", encoding="utf-8") as out:
            for page_path in page_files:
                with open(page_path, "r", encoding="utf-8") as handle:
                    records = json.load(handle)
                for record in records:
                    out.write(json.dumps(record, ensure_ascii=False))
                    out.write("\n")
        return out_path

    # Default: a single JSON array. Stream page-by-page so we never hold every
    # entity's full dataset in memory at once beyond a single page.
    out_path = os.path.join(output_dir, f"{entity_name}_{timestamp}.json")
    with open(out_path, "w", encoding="utf-8") as out:
        out.write("[")
        first = True
        for page_path in page_files:
            with open(page_path, "r", encoding="utf-8") as handle:
                records = json.load(handle)
            for record in records:
                if not first:
                    out.write(",")
                out.write("\n  ")
                out.write(json.dumps(record, ensure_ascii=False))
                first = False
        out.write("\n]" if not first else "]")
    return out_path


# --------------------------------------------------------------------------- #
# Entry point
# --------------------------------------------------------------------------- #
def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        default="config.json",
        help="Path to the configuration file (default: config.json).",
    )
    parser.add_argument(
        "--page-size",
        type=int,
        default=None,
        help="Override the page size from config.",
    )
    parser.add_argument(
        "--entities",
        nargs="*",
        default=None,
        help="Only extract these entity names (default: all enabled).",
    )
    parser.add_argument(
        "--format",
        choices=["array", "ndjson"],
        default=None,
        help="Override output format from config.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config = load_config(args.config)

    api_cfg = config.get("api", {})
    output_cfg = config.get("output", {})
    queries_dir = config.get("queries_directory", "queries")

    # Resolve the bearer token from the environment; never from the config file.
    token_env = api_cfg.get("token_env", "IDS_BRIDGE_TOKEN")
    token = os.environ.get(token_env, "")
    if not token:
        log.error(
            "No access token found. Set the %s environment variable.", token_env
        )
        return 1

    # CLI overrides take precedence over config values.
    page_size = args.page_size or config.get("pagination", {}).get("page_size", 100)
    output_format = args.format or output_cfg.get("format", "array")
    output_dir = output_cfg.get("directory", "output")
    pages_subdir = output_cfg.get("pages_subdirectory", "pages")
    # Page files are intermediate; by default they are deleted after a
    # successful merge so no duplicate data is left on disk.
    keep_page_files = bool(output_cfg.get("keep_page_files", False))

    # Single timestamp for the whole run; every final file carries this suffix
    # so repeated runs never overwrite previously generated data.
    run_timestamp = time.strftime("%Y%m%d_%H%M%S")

    os.makedirs(output_dir, exist_ok=True)

    # Select the entities to run.
    all_entities = config.get("entities", [])
    if args.entities:
        wanted = set(args.entities)
        selected = [e for e in all_entities if e.get("name") in wanted]
    else:
        selected = [e for e in all_entities if e.get("enabled", True)]

    if not selected:
        log.error("No entities selected to extract.")
        return 1

    # One shared, keep-alive HTTP session for all requests.
    session = requests.Session()
    session.headers.update(
        {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        }
    )

    log.info(
        "Starting extraction: %d entities, page size %d, format %s -> %s/",
        len(selected),
        page_size,
        output_format,
        output_dir,
    )

    results: list[EntityResult] = []
    for entity in selected:
        # Each entity is fully isolated: an exception here can never abort the
        # loop, guaranteeing the run continues across all entities.
        try:
            result = extract_entity(
                session,
                entity,
                api_cfg,
                queries_dir,
                page_size,
                output_dir,
                pages_subdir,
                output_format,
                keep_page_files,
                run_timestamp,
            )
        except Exception as exc:  # noqa: BLE001 - last-resort safety net
            result = EntityResult(name=entity.get("name", "<unknown>"))
            result.status = "failed"
            result.errors.append(f"unexpected error: {exc}")
            log.exception("[%s] unexpected error", result.name)
        results.append(result)

    # Write a machine-readable run summary next to the outputs.
    summary = {
        "run_timestamp": run_timestamp,
        "page_size": page_size,
        "output_format": output_format,
        "entities": [r.as_dict() for r in results],
        "totals": {
            "entities": len(results),
            "records": sum(r.records_fetched for r in results),
            "ok": sum(1 for r in results if r.status == "ok"),
            "partial": sum(1 for r in results if r.status == "partial"),
            "failed": sum(1 for r in results if r.status == "failed"),
        },
    }
    summary_path = os.path.join(output_dir, f"_run_summary_{run_timestamp}.json")
    with open(summary_path, "w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2)

    # Console summary table.
    log.info("=" * 60)
    log.info("Extraction summary:")
    name_width = max((len(r.name) for r in results), default=10)
    for r in results:
        expected = r.expected_total if r.expected_total is not None else "?"
        log.info(
            "  %-*s  %-8s  %s / %s records",
            name_width,
            r.name,
            r.status,
            f"{r.records_fetched:,}",
            f"{expected:,}" if isinstance(expected, int) else expected,
        )
    log.info(
        "Totals: %d records across %d entities (ok=%d partial=%d failed=%d)",
        summary["totals"]["records"],
        summary["totals"]["entities"],
        summary["totals"]["ok"],
        summary["totals"]["partial"],
        summary["totals"]["failed"],
    )
    log.info("Summary written to %s", summary_path)

    # Non-zero exit only if nothing succeeded, so orchestration can detect a
    # total failure while still treating partial runs as a soft success.
    return 0 if summary["totals"]["ok"] > 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
