"""Generate parameterized GraphQL query files and a config.json from a Postman
collection exported by IDS Bridge.

Why this exists
---------------
The Postman collection stores one GraphQL query per entity, but every query
hard-codes its pagination arguments (``page: 1`` / ``first: 100``). To paginate
programmatically we convert each query into a reusable *template* that accepts
GraphQL variables ``$page`` and ``$first``. Each template is written to its own
``.graphql`` file so the field list stays easy to read and edit by hand later.

Outputs
-------
* ``queries/<root_field>.graphql`` - one parameterized query per entity.
* ``config.json``                  - manifest consumed by ``ids_extract.py``.

Usage
-----
    python generate_queries.py \
        --collection "IDS Bridge.postman_collection.json" \
        --out-dir .

Re-run this whenever the Postman collection changes. Hand edits to the
generated ``.graphql`` files are preserved unless you pass ``--overwrite``.
"""

from __future__ import annotations

import argparse
import json
import os
import re
from typing import Optional

# Matches the pagination arguments regardless of the concrete number used.
# ``page: 1`` -> ``page: $page`` and ``first: 100`` -> ``first: $first``.
RE_PAGE_ARG = re.compile(r"\bpage:\s*\d+")
RE_FIRST_ARG = re.compile(r"\bfirst:\s*\d+")

# Captures the first root field after ``query {`` (e.g. ``campaigns``), which is
# the field we read records and paginatorInfo from in the response.
RE_ROOT_FIELD = re.compile(r"query\s*\{\s*([A-Za-z_][A-Za-z0-9_]*)")

# Item names in the collection flagged as not usable against the live schema.
DISABLED_MARKERS = ("UNAVAILABLE", "UNAUTHORIZED")


def parameterize_query(raw_query: str) -> str:
    """Convert a hard-coded Postman query into a variable-driven template.

    * Injects the ``$page`` / ``$first`` variable declarations on the operation.
    * Rewrites the literal pagination arguments to reference those variables.
    """
    # 1. Add variable declarations to the anonymous operation definition. We only
    #    replace the very first ``query {`` so nested selection sets are untouched.
    query = raw_query.replace(
        "query {",
        "query paginatedQuery($page: Int!, $first: Int!) {",
        1,
    )

    # 2. Point the pagination arguments at the new variables.
    query = RE_PAGE_ARG.sub("page: $page", query)
    query = RE_FIRST_ARG.sub("first: $first", query)

    # Normalise Windows newlines that Postman embeds in the exported JSON.
    return query.replace("\r\n", "\n")


def extract_root_field(query: str) -> Optional[str]:
    """Return the top-level query field name, or None if it cannot be found."""
    match = RE_ROOT_FIELD.search(query)
    return match.group(1) if match else None


def load_collection(path: str) -> list[dict]:
    """Read the Postman collection and return its list of request items."""
    with open(path, "r", encoding="utf-8") as handle:
        collection = json.load(handle)
    return collection.get("item", [])


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--collection",
        default="IDS Bridge.postman_collection.json",
        help="Path to the exported Postman collection JSON file.",
    )
    parser.add_argument(
        "--out-dir",
        default=".",
        help="Directory where queries/ and config.json are written.",
    )
    parser.add_argument(
        "--page-size",
        type=int,
        default=100,
        help="Default page size recorded in config.json.",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite existing .graphql files (default: skip existing).",
    )
    args = parser.parse_args()

    queries_dir = os.path.join(args.out_dir, "queries")
    os.makedirs(queries_dir, exist_ok=True)

    items = load_collection(args.collection)
    entities: list[dict] = []

    for item in items:
        name = item.get("name", "")
        request = item.get("request", {})
        body = request.get("body", {})
        raw_query = (body.get("graphql") or {}).get("query", "")

        if not raw_query:
            print(f"SKIP  {name!r}: no GraphQL query body found.")
            continue

        root_field = extract_root_field(raw_query)
        if not root_field:
            print(f"SKIP  {name!r}: could not detect root query field.")
            continue

        template = parameterize_query(raw_query)
        query_filename = f"{root_field}.graphql"
        query_path = os.path.join(queries_dir, query_filename)

        # Preserve manual edits unless the caller explicitly opts in.
        if os.path.exists(query_path) and not args.overwrite:
            print(f"KEEP  {query_filename} (already exists)")
        else:
            with open(query_path, "w", encoding="utf-8") as handle:
                handle.write(template)
            print(f"WRITE {query_filename}")

        # Entities flagged in the collection name are disabled by default so a
        # full run does not fail on endpoints the token cannot reach.
        enabled = not any(marker in name.upper() for marker in DISABLED_MARKERS)

        entities.append(
            {
                "name": root_field,
                "root_field": root_field,
                "query_file": query_filename,
                "enabled": enabled,
            }
        )

    config = {
        "api": {
            "url": "https://sg.idsdatanet.com/ids-bridge/v3/graphql",
            # Name of the environment variable holding the bearer token.
            "token_env": "IDS_BRIDGE_TOKEN",
            "timeout_seconds": 120,
            "max_retries": 3,
            "retry_backoff_seconds": 2,
        },
        "pagination": {
            "page_size": args.page_size,
        },
        "output": {
            "directory": "output",
            "pages_subdirectory": "pages",
            # Delete per-page JSON files after a successful merge (no duplicate
            # data left on disk). Set true to retain them for auditing.
            "keep_page_files": False,
            # "array" -> single JSON array file; "ndjson" -> one object per line
            # (recommended for Snowflake COPY INTO).
            "format": "array",
        },
        "queries_directory": "queries",
        "entities": entities,
    }

    config_path = os.path.join(args.out_dir, "config.json")
    with open(config_path, "w", encoding="utf-8") as handle:
        json.dump(config, handle, indent=2)
    print(f"\nWrote {config_path} with {len(entities)} entities.")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
